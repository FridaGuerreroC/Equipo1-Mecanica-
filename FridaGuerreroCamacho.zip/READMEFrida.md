El problema nos dice lo siguiente:
Usted frena su Porsche desde la velocidad de 85 km/h, hasta 45 km/h en una distancia de 105 m. a) Cual es la aceleracion, suponiendo que sea constante el intervalo? b) Que tanto tiempo?  c)Que tiempo transcurrio durante el intervalo? d)Si usted fuera a continuar frenando con la misma aceleracion, Que tiempo le tomaria detenerse? e)Que distancia tendria que cubrir?

El programa realizado nos resuelve problemas como este, para esto cuenta con 4 funciones para resolver los 5 incisos, cuenta con
una simulacion de un auto que esta en movimiento

Para poder ejecutar el programa, necesita de tener un programa llamado DEV C, en el cual podra compilar el problema y viualizar la solucion.
Para poder visualizar la simulacion del automovil, debera instalar las librerias de c grphics


