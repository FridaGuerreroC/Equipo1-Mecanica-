#include <stdlib.h>
#include <stdio.h>

void SolucionA();
void SolucionB();
void SolucionC();
void SolucionD();

int main() {
    printf("Programa de Movimiento Rectilineo Uniformemente Acelerado\n");

    while (1) {
        printf("\nUsted frena su Porsche desde la velocidad de 85 km/h, hasta 45 km/h en una distancia de 105 m\n\n");
        printf("a) Cual es la aceleracion, suponiendo que sea constante el intervalo?\n");
        printf("b) Que tanto tiempo?\n");
        printf("c) Que tiempo transcurrio durante el intervalo?\n");
        printf("d) Si usted fuera a continuar frenando con la misma aceleracion, Que tiempo le tomaria detenerse?\n");
        printf("e) Que distancia tendria que cubrir?\n");
        printf("f) Salir del programa\n");

        char opc;
        printf("\n\nIngrese la letra de la solucion que quiera visualizar (f para salir): \n");
        scanf(" %c", &opc);

        switch (opc) {
            case 'a':
                SolucionA();
                system("pause");
                system("cls");
                break;
            case 'b':
                SolucionB();
                system("pause");
                system("cls");
                break;
            case 'c':
                SolucionC();
                system("pause");
                system("cls");
                break;
            case 'd':
                SolucionD();
                system("pause");
                system("cls");
                break;
            case 'e':
                printf("Opci�n no implementada.\n");
                system("pause");
                system("cls");
                break;
            case 'f':
                printf("Saliendo del programa...\n");
                system("pause");
                system("cls");
                exit(0);
            default:
                printf("Opcion no valida.\n");
                system("pause");
                system("cls");
                break;
        }
    }

    return 0;
}

void SolucionA() {
    printf("Seleccionaremos primero que la direccion positiva sera la direccion de la velocidad, y"); 
	printf("elijamos el origen de modo que x0 = 0 cuando comienza a frenar.\n");
    printf("Hemos dado la velocidad inicial igual a 85 km/h en el tiempo igual a cero, y sabemos"); 
	printf("que la velocidad final es 45 km/h en el tiempo t\n");
    printf("siendo el desplazamiento de 0.105 km.\n");
    printf("Necesitamos una ecuacion que incluya la aceleracion desconocida que buscamos, pero en la");
	printf("que no intervenga el tiempo.\n");
    printf("La ecuacion de a es nuestra opcion.\n");

    int v = 45; // Velocidad final, inicializada en 45 km/h
    int v0 = 85; // Velocidad inicial, inicializada en 85 km/h
    float x = 0.105; // Desplazamiento, inicializado en 0.105 km
    float x0 = 0; // Desplazamiento inicial, inicializado en 0 km

    float aceleracion;

    if (x - x0 != 0) {
        aceleracion = (v * v - v0 * v0) / (2 * (x - x0));
        printf("\nEl resultado de la aceleracion es: %f km/h^2\n", aceleracion);
    } else {
        printf("\nError: el resultado no es correcto\n");
    }
}

void SolucionB() {
    printf("\nNecesitamos una ecuacion que no incluya la aceleracion, lo que nos permite hallar");
	printf("el tiempo a partir de los datos originales.\n");

    float d = 0.105;
    int x_0 = 0;
    int v_0 = 85;
    int vel = 45;

    float tiempo;

    if (d - x_0 != 0) {
        tiempo = (2 * (d - x_0)) / (v_0 + vel);
        printf("\nEl resultado del tiempo es: %f h\n", tiempo);
    } else {
        printf("\nError: el resultado no es correcto\n");
    }
}

void SolucionC() {
    printf("\nAhora que ya conocemos la aceleracion, buscaremos el tiempo t para que el");
	printf("automovil pase de v0 = 85km/h a v = 0.\n");

    int Vf = 0;
    int Vo = 85;
    double a = -24761.906250;
    float t;

    if (Vf - Vo != 0) {
        t = (Vf - Vo) / (a);
        printf("\nEl resultado del tiempo es: %f h\n", t);
    } else {
        printf("\nError: el resultado es erroneo\n");
    }
}

void SolucionD() {
    printf("\nPara la distancia adicional:\n");

    int Vf = 0;
    int Vo = 45;
    float a = -24761.906250;
    float d_A;

    if (Vf - Vo != 0) {
        d_A = (Vf * Vf - Vo * Vo) / (2 * a);

        printf("\nEl resultado de la distancia adicional es: %f km\n", d_A);
    } else {
        printf("\nError: el resultado es incorrecto.\n");
    }
    printf("\nLa distancia adicional viajada entre el punto");
	printf("v = 45 km/h es de 0.146 km - 0.105 km = 0.41 km\n");
}

