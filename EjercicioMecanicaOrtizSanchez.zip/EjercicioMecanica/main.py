#Ortiz Felipe
#Programa caida libre
#comando de ejecucion python main.py
import math
import pygame
import time
 
 #Funcion principal que se encarga de pedir los datos para realizar los calculos
def main():
    velIni = float(input("Ingresa el valor de la velocidad inicial: \n"))
    velFin = float(input("Ingrese el valor de la velocidad final: \n"))
    time = CalcularTiempo(velIni, velFin)
    print("El valor del tiempo es de: " + str(time) + "s")
    y = CalcularAltura(velIni, velFin)
    print("El valor de la altura en y es de: " + str(y) + "m")
    y_inicial = float(input("Ingresa el valor de la posición inicial en y: "))
    posY = float(input("Ingresa la posición inicial donde quieres calcular su tiempo de llegada: \n"))
    g = 9.81
    timeTot = CalcularTiempoPosicion(y_inicial, velIni, posY, g)

    if timeTot is not None:
        for tiempo in timeTot:
            print("El tiempo de llegada es de {:.2f} segundos".format(tiempo))
    else:
        print("No hay tiempo de llegada válido para la posición dada.")
    
    pygameView()


#Calcula el tiempo de vuelo desde el inicio hasta la altura final
def CalcularTiempo(velIni,  velFin ):
    time : float
    
    time = (velIni-velFin)/9.81
    time = "{:.2f}".format(time)
    return time

#Calcula la altura total que alcanza la pelota en su vuelo
def CalcularAltura(velIni, velFin):
    posFin:float

    posFin = ((velIni**2)-(velFin**2))/(2*9.81)
    posFin = "{:.2f}".format(posFin)
    return posFin

#Calcula el o los tiempos donde la pelota alcanza un punto dado en metros, de no alcanzarlo nos dira que no lo alcanzo
def CalcularTiempoPosicion(y_inicial, v_inicial, y, g):
    discriminante = v_inicial**2 - 2 * g * (y - y_inicial)

    if discriminante >= 0:
        t1 = (v_inicial + math.sqrt(discriminante)) / g
        t2 = (v_inicial - math.sqrt(discriminante)) / g

        return [t1, t2]
    else:
        return None

#funcion para crear una simulacion simple de una pelota viajando hacia arriba
def pygameView():
    # Inicializar Pygame
    pygame.init()

    # Definir las dimensiones de la ventana
    width = 800
    height = 800

    # Crear la ventana de visualización
    window = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Simulación de Pelota")

    # Definir los colores (R, G, B)
    white = (255, 255, 255)
    blue = (0, 0, 255)

    # Definir los parámetros de la pelota
    radius = 20
    x = width // 2
    y = height - radius
    velocity = 5
    angle = math.radians(90)  # Ángulo de lanzamiento vertical hacia arriba
    gravity = 0.5  # Gravedad hacia abajo

    # Definir los parámetros de la flecha
    arrow_length = 30

    # Bucle principal del juego
    running = True
    while running:
        # Manejo de eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Actualizar posición horizontal y vertical de la pelota
        vx = velocity * math.cos(angle)  # Componente horizontal de la velocidad
        vy = velocity * math.sin(angle)  # Componente vertical de la velocidad
        x += vx
        y -= vy
        vy += gravity  # Cambio de signo para simular la caída

        # Verificar los límites de la ventana
        if y > height - radius:
            y = height - radius
            vy = -abs(vy) * 0.9  # Invertir la velocidad vertical con una pequeña pérdida de energía (factor 0.9)

        if x < radius:
            x = radius
            vx = abs(vx) * 0.9  # Hacer positiva la velocidad horizontal con una pequeña pérdida de energía (factor 0.9)

        if x > width - radius:
            x = width - radius
            vx = -abs(vx) * 0.9  # Hacer negativa la velocidad horizontal con una pequeña pérdida de energía (factor 0.9)

        # Limitar los valores de x y y dentro de los límites de la ventana
        if x < radius:
            x = radius
        elif x > width - radius:
            x = width - radius

        if y < radius:
            y = radius
        elif y > height - radius:
            y = height - radius

        # Rellenar la ventana con color blanco
        window.fill(white)

        # Dibujar la pelota en la ventana
        pygame.draw.circle(window, blue, (int(x), int(y)), radius)

        # Calcular las coordenadas de la flecha en relación a la pelota
        arrow_x = x + radius
        arrow_y = y - arrow_length

        # Dibujar la flecha
        arrow_points = [(arrow_x, arrow_y), (arrow_x + 10, arrow_y + 10), (arrow_x, arrow_y + 20)]
        pygame.draw.polygon(window, blue, arrow_points)

        # Actualizar la ventana de visualización
        pygame.display.update()

        # Detener la simulación cuando la pelota toca el suelo
        if y >= height - radius:
            running = False

        # Controlar la velocidad de la simulación
        pygame.time.Clock().tick(60)  # 60 fps

    # Pausa de 3 segundos antes de finalizar el programa
    time.sleep(3)

    # Finalizar Pygame
    pygame.quit()

if __name__ == "__main__":
    main()
