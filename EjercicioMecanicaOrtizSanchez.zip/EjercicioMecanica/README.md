El problema nos dice lo siguiente:
Una pelota se lanza verticalmente hacia arriba desde el suelo a una velocidad de 25.2m/s. a)Cuanto tiempo tarda en llegar al punto mas elevado. b)A que altura se eleva? c) en cuanto tiempo estara 27.0m sobre el suelo?

El programa realizado nos resuelve problemas como este, para esto cuenta con 3 funciones para resolver los 3 inciso, cuenta con
una simulacion de una pelota siendo lanzada hacia arriba.

El comando de ejecucion seria python main.py

Para que este programa funcione correctamente se necesita tener instalada una version de python y aparte se necesita istalar la libreria pygames esta se instala desde el simbolo de sistema utilizando el siguiente comando:

pip install pygame