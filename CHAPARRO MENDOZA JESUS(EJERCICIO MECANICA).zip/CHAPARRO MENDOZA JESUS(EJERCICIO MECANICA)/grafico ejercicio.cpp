#include <stdio.h>
#include <stdlib.h>
#include<graphics.h>
#include<conio.h>

//prototipos
void juego();

int main(){

	system("color B");
	
	juego();
	
	return 0;
}

//definicion de funciones


void juego(){
	
	initwindow(630, 350, "VENTANA");
	
		setfillstyle(SOLID_FILL,WHITE);
		floodfill(1,1,WHITE);				
		settextstyle(3,0,3);
		
	
		outtextxy(230,50,"LEY DE COULOMB");
		
	
		
		
	setbkcolor(RED);
	
	setcolor(BLACK);
	rectangle(0, 0, 700, 350);
	setfillstyle(SOLID_FILL, BLACK);
	floodfill(2, 2, BLACK);
	
	//TORRES
	
	//Torre 1
	setcolor(WHITE);
	rectangle(100,180, 500, 190);
	setfillstyle(4, WHITE);
	floodfill(101, 181, WHITE);
	
	setfillstyle(SOLID_FILL,RED);
		fillellipse(70,185,50,50);
		
		setfillstyle(SOLID_FILL,RED);
		fillellipse(550,185,50,50);
		
		
			outtextxy(58,170,"Q1");
			
			outtextxy(538,170,"Q2");
			
			setbkcolor(BLACK);
		
			
			outtextxy(265,200,"<---  d  --->");
			
			outtextxy(198,147,">");
			
			
			
	setcolor(YELLOW);
	//flecha izquierda
	
		line(110,160,200,160);
		
		outtextxy(198,147,">");
		
		
	// flecha derecha	
		line(410,160,505,160);
		
		outtextxy(400,147,"<");
			
		
	

		getch();
	
}