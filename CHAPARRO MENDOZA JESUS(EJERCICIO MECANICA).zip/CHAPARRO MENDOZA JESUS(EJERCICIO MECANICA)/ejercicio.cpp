#include <iostream>
#include <cmath>

int main()
 {
	system("color B");
	
    double q1=0.000003, q2=-0.000008, r=2, F,F2,F3;
    const double k = 9e9;

	
	printf("Una carga de 3x10^-6 C se encuentra 2 m de una carga de -8x10^-6 C, Cual es la magnitud de la fuerza de atraccion entre las cargas\n\n");
	
    // Calcular la fuerza de atracción
    
    F = (q1 * q2)/(r*r);
    
    F2 = F * k;
    
    F3 = (F2)*(-1);
    
       printf("DATOS\n\n");
    
    printf("q1 = 3x10^-6 \n");
    
    printf("q2 = -8x10^-6 \n");
    
    printf("k = 9x10^9 \n");
    
    printf("d = 2 \n\n");
    
    
    
    printf("FORMULA\n\n");
    
    printf("\nF = K *  (q1*q2)\n        --------- \n          (d)^2\n\n");
    
    

    printf("La magnitud de la fuerza de atraccion entre las cargas es: %lf N\n", F2);
    
    printf("\n\n Vemos que hay un signo negativo, por ahora no nos sirve interpretar el signo, \n puesto que el problema nos pide la magnitud de la fuerza,");
	printf("esto quiere decir que tomaremos la fuerza \n como un valor absoluto, que vendria a ser nuestro resultado.");
	
	
	printf("\n\nLa fuerza de atraccion entre las cargas es: %lf N\n", F3);


    return 0;
}