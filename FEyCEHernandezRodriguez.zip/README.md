# # Equipo1-Mecanica-y-Electromagnetismo

# Calculadora de Fuerza Electrostática y Campo Eléctrico

Este programa calcula la fuerza electrostática entre dos cargas estáticas y el campo eléctrico generado por cada una de ellas. Permite al usuario ingresar las cargas en notación científica y la distancia entre las partículas para realizar los cálculos correspondientes.

## Compilación

El programa puede ser compilado en entornos que admitan el lenguaje de programación C. A continuación, se muestra un ejemplo de compilación en sistemas Windows utilizando el compilador GCC:

gcc CalcuElectrostática.c -o nombre_ejecutable

Reemplaza `nombre_ejecutable` con el nombre deseado para el archivo ejecutable resultante.

## Ejecución

Una vez compilado, el programa se puede ejecutar utilizando el siguiente comando:

/nombre_ejecutable

Reemplaza `nombre_ejecutable` con el nombre del archivo ejecutable generado durante la compilación.

Durante la ejecución, se solicitarán los datos requeridos para el cálculo de la fuerza electrostática y el campo eléctrico. Sigue las instrucciones proporcionadas por el programa para ingresar las cargas y la distancia.

Los valores de las cargas que se lleguen a ingresar son de la siguiente manera: 21.3x10^-6 o 21.3*10^-6, cualquiera de las dos formas será correcta por el programa, los resultados se esperan de igual forma tener en notación cientifica.

Se muestra un diagrama de estas cargas, para una mejor comprensión del tema. Recordemos que son cargas estácticas, las cuales no se mueven en el plano.

## Autor

Este programa fue desarrollado por Hernández Rodríguez Brayan.

## Atribuciones

El cálculo de la fuerza electrostática y el campo eléctrico se basa en la constante electrostática definida como `K = 8.99e9` en el programa.

## Contribuciones

Las contribuciones a este proyecto son bienvenidas. Si encuentras algún error o tienes alguna mejora que sugerir, no dudes en abrir un problema o enviar una solicitud de extracción.
