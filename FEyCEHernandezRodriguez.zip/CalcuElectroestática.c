/*
    PROGRAMA: Calculadora de fuerza elecrostatica y campo electrico
    
    FUNCIÓN DEL PROGRAMA: Este programa realiza el calculo de la fuerza de dos cargas estáticas
    realizando un diagrama de cómo estarían en un plano horizontal(unicamente en el eje de las x),
    al igual de que realiza el calculo del campo eléctrico en cada una de las cargas.
    
    AUTOR: Hernández Rodríguez Brayan

    COMPILACIÓN EN WINDOWS: gcc CalcuElectrostática.c -o (nombre del ejecutable)

    El usuario decide el nombre del ejecutable

    EJECUCIÓN: (nombre del ejecutable).exe

    Durante la ejecución se piden los datos requeridos para dicho cálculo.
*/

//Librerías utilizadas
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define K 8.99e9 // Definición de la Constante electrostática

/*
    DESCRIPCIÓN: Está función imprime un diagrama que representa 
    las dos partículas cargadas y la distancia entre ellas.

    PARÁMETROS:
    -q1Sign: Carácter que indica el signo de la carga de 
    la partícula q1 ('+' para carga positiva, '-' para carga negativa).
    -q2Sign: Carácter que indica el signo de la carga de
    la partícula q2 ('+' para carga positiva, '-' para carga negativa).
    -distance: Valor de la distancia entre las particulas

    VALOR DE RETORNO: Ninguno
*/
void printDiagram(char q1Sign, char q2Sign, double distance) {
    printf("    ______                  ______\n");
    printf("   |      |  r = %.2lf m    |      |\n", distance);
    printf("   | q1 %c |----------------| q2 %c |\n", q1Sign, q2Sign);
    printf("   |______|                |______|\n");
    printf("\n");
}


/*
    DESCRIPCIÓN: Esta función formatea un número en notación científica 
    y lo guarda en un búfer de caracteres.

    PARÁMETROS:
    -value: Valor numérico que se formateará en notación científica.
    -buffer: Puntero al búfer de caracteres donde se almacenará el 
    resultado formateado.
    -bufferSize: Tamaño máximo del búfer de carácteres.

    VALOR DE RETORNO: Ninguno.
*/
void formatScientificNotation(double value, char *buffer, size_t bufferSize) {
    double absValue = fabs(value);
    int exponent = 0;
    int negativeExponent = 0;

    // Determine the exponent
    if (absValue >= 1) {
        while (absValue >= 10) {
            absValue /= 10;
            exponent++;
        }
    } else {
        while (absValue > 0 && absValue < 1) {
            absValue *= 10;
            exponent--;
        }
        negativeExponent = 1; // Set the flag for negative exponent
    }

    // Format the value as a string with a negative exponent if necessary
    if (negativeExponent) {
        snprintf(buffer, bufferSize, "%.2fx10^-%d", absValue, -exponent);
    } else {
        snprintf(buffer, bufferSize, "%.2fx10^-%d", absValue, exponent);
    }
}

/*
    DESCRIPCIÓN: Esta función calcula el campo eléctrico producido por
    una carga en un punto específico.
    
    PARÁMETROS:
    -charge: Valor de la carga eléctrica.
    -distance: Valor de la distancia entre la carga y el punto donde se
    calcula el campo eléctrico.
    -electricField: Puntero a una variable donde se almacenará el
    resultado del campo eléctrico calculado.

    VALOR DE RETORNO: Ninguno.
*/
void calculateElectricField(double charge, double distance, double *electricField) {
    *electricField = K * charge / pow(distance, 2);
}

/*
    Solicita al usuario las cargas de las partículas (en notación científica)
    y la distancia entre ellas

    Procesa las cargas en notación científica y las convierte en valores
    numéricos.

    Calcula la fuerza electrostática y el campo eléctrico utilizando la
    constante electrostática "k" y los valores de carga y distancia proporcionados.

    Imprime el diagrama, las cargas, la distancia, la fuerza electrstática,
    la interacción entre las cargas y el campo eléctrico de cada partícula.

    Utiliza la función "formatScientificNotation" para formatear los valores
    en notación científica personalizada antes de imprimirlos.
*/
int main() {
    char q1Str[50], q2Str[50];
    double distance;
    double force;
    double q1ElectricField, q2ElectricField;

    // Obtener las cargas de las partículas y la distancia entre ellas
    printf("Ingrese la carga de la particula q1 (+/-) en notacion cientifica: ");
    scanf("%s", q1Str);

    printf("Ingrese la carga de la particula q2 (+/-) en notacion cientifica: ");
    scanf("%s", q2Str);

    printf("Ingrese la distancia entre las particulas: ");
    scanf("%lf", &distance);

    // Procesar las cargas en notación científica
    double q1Coefficient, q1Exponent;
    double q2Coefficient, q2Exponent;

    sscanf(q1Str, "%lfx10^%[-0-9]lf", &q1Coefficient, &q1Exponent);
    sscanf(q2Str, "%lfx10^%[-0-9]lf", &q2Coefficient, &q2Exponent);

    // Calcular la carga de q1 y q2
    double q1 = q1Coefficient * pow(10, q1Exponent);
    double q2 = q2Coefficient * pow(10, q2Exponent);

    // Calcular la fuerza electrostática
    force = K * q1 * q2 / pow(distance, 2);
    force = round(force * 100) / 100; // Redondear a dos decimales

    // Calcular el campo eléctrico de q1 y q2
    calculateElectricField(q1, distance, &q1ElectricField);
    calculateElectricField(q2, distance, &q2ElectricField);

    // Determinar la interacción entre las cargas
    char* interaction = (q1 * q2 > 0) ? "repulsion" : "atraccion";

    // Mostrar el diagrama y los resultados
    printf("\n");
    printDiagram((q1 > 0) ? '+' : '-', (q2 > 0) ? '+' : '-', distance);
    printf("Carga de q1: %s C\n", q1Str);
    printf("Carga de q2: %s C\n", q2Str);
    printf("Distancia entre las particulas: %.2lf\n", distance);

    // Formatear la fuerza electrostática en notación científica personalizada
    char formattedForce[50];
    formatScientificNotation(force, formattedForce, sizeof(formattedForce));

    printf("Fuerza electrostatica: %s N\n", formattedForce);
    printf("Interaccion: %s\n", interaction);

    // Formatear el campo eléctrico en notación científica personalizada
    char formattedQ1ElectricField[50];
    formatScientificNotation(q1ElectricField, formattedQ1ElectricField, sizeof(formattedQ1ElectricField));

    char formattedQ2ElectricField[50];
    formatScientificNotation(q2ElectricField, formattedQ2ElectricField, sizeof(formattedQ2ElectricField));

    printf("Campo electrico de q1: %s N/C\n", formattedQ1ElectricField);
    printf("Campo electrico de q2: %s N/C\n", formattedQ2ElectricField);

    return 0;
}
