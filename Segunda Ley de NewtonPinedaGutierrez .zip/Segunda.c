#include<stdio.h>
#include<stdlib.h>
#include<math.h>

float FormulaNormal(float fuerza, float masa, float aceleracion);
void DosFuerzas(float fuerza1, float fuerza2, float masa, float aceleracion, int angulo1, int angulo2, int anguloA);
void TresFuerzas(float fuerza1, float fuerza2, float fuerza3, float masa, float aceleracion, int angulo1, int angulo2, int angulo3, int anguloA);

int main()
{
    int op, op2;
    float fuerza, fuerza1, masa, aceleracion;
    int angulo1, angulo2, anguloA;
    printf("1. Formula Simple\n");
    printf("2. Con dos fuerzas\n");
    printf("Como quiere realizar el problea?: ");
    scanf("%d", &op);

    switch (op)
    {
    case 1:
        printf("Que necesitas calcular?\n");
        printf("1. Fuerza\n");
        printf("2. Masa\n");
        printf("3. Aceleracion\n");
        scanf("%d", &op2);
        switch(op2)
        {
            case 1:
                printf("Ingresa la masa: \n");
                scanf("%f", &masa);
                printf("Ingresa la aceleracion: \n");
                scanf("%f", &aceleracion);

                fuerza = FormulaNormal(0, masa, aceleracion);

                printf("La fuerza total es de: %0.2f N", fuerza);
            break;
            case 2:
                printf("Ingresa la fuerza: \n");
                scanf("%f", &fuerza);
                printf("Ingresa la aceleracion: \n");
                scanf("%f", &aceleracion);

                masa = FormulaNormal(fuerza, 0, aceleracion);

                printf("La masa del objeto es de: %0.2f kg", masa);
            break;
            case 3:
                printf("Ingresa la fuerza: \n");
                scanf("%f", &fuerza);
                printf("Ingresa la masa: \n");
                scanf("%f", &masa);

                aceleracion = FormulaNormal(fuerza, masa, 0);

                printf("La aceleracion es de %0.2f m/s2", aceleracion);
            break;
        }
        break;
        case 2:
            printf("\nIngresa la magnitud de la fuerza 1 (De no tenerla ingrese un 0): ");
            scanf("%f", &fuerza);
            printf("\nIngresa la magnitud de la fuerza 2 (De no tenerla ingrese un 0): ");
            scanf("%f", &fuerza1);
            printf("\nIngresa la masa (De no tenerla ingrese un 0): ");
            scanf("%f", &masa);
            printf("\nIngresa la magnitud de la aceleracion (De no tenerla ingrese un 0): ");
            scanf("%f", &aceleracion);
            printf("\nIngresa el angulo de la fuerza 1: ");
            scanf("%d", &angulo1);
            printf("\nIngresa el angulo de la fuerza 2: ");
            scanf("%d", &angulo2);
            printf("\nIngresa el angulo del vector aceleracion: ");
            scanf("%d", &anguloA);

            DosFuerzas(fuerza, fuerza1, masa, aceleracion, angulo1, angulo2, anguloA);
        break;
    default:
    printf("Ingresa una opcion valida.");
        break;
    }
}

float FormulaNormal(float fuerza, float masa, float aceleracion)
{
    if (fuerza == 0)
    {
        fuerza = masa * aceleracion;
        return fuerza;
    }
    else if (masa == 0)
    {
        masa = fuerza/aceleracion;
        return masa;
    }
    else
    {
        aceleracion = fuerza / masa;
        return aceleracion;
    } 
}

void DosFuerzas(float fuerza1, float fuerza2, float masa, float aceleracion, int angulo1, int angulo2, int anguloA)
{
    double fx1, fx2, fy1, fy2, pi, ax, ay, magnitud, p1, p2, sum;

    pi = acos(-1);
    fx1 = fuerza1*cos(angulo1 * pi/180);
    fx2 = fuerza2*cos(angulo2 * pi/180);

    fy1 = fuerza1*sin(angulo1 * pi/180);
    fy2 = fuerza2*sin(angulo2 *pi/180);

    ax = aceleracion*cos(anguloA * pi/180);
    ay = aceleracion*sin(anguloA * pi/180);

    if (fuerza1 == 0)
    {
        fx1 = (masa*ax)-fx2;
        fy1 = (masa*ay)-fy2;
        printf("\nEl vector f1= (%0.2lf)i + (%0.2lf)j", fx1, fy1);
        p1 = fx1 * fx1;
        p2 = pow(fy2, 2);
        sum = p1 + p2;
        magnitud = sqrt(sum);

        printf("\nLa magnitud de la fuerza 1 es de: %0.2lf", magnitud);
    }
    else if (fuerza2 == 0)
    {
        fx2 = (masa*ax)-fx1;
        fy2 = (masa*ay)-fy2;
        printf("\nEl vector f1= (%0.2lf)i + (%0.2lf)j", fx1, fx2);
        p1 = pow(fx2, 2);
        p2 = pow(fy2, 2);
        magnitud = sqrt(p1+p2);

        printf("\nLa magnitud de la fuerza 2 es de: %0.2lf", magnitud);
    }
    else if (masa == 0)
    {
        masa = (fx1 + fx2)/ax;
        printf("\nLa masa del objeto es de: %0.2lf", masa);
    }
    else
    {
        ax = (fx1+fx2)/masa;
        ay = (fy1+fy2)/masa;

        printf("\nLa aceleracion como vector es a= (%0.2lf)i + (%0.2lf)j");

        p1 = pow(ax, 2);
        p2 = pow(ay, 2);
        magnitud = sqrt(p1+p2);

        printf("\nLa magnitud de la aceleracion es de: %0.2lf", magnitud);
    }
}

void TresFuerzas(float f1, float f2, float f3, float masa, float a, int ang1, int ang2, int ang3, int angA)
{
    double fx1, fx2, fx3, fy1, fy2, fy3, pi, ax, ay, magnitud, p1, p2;

    pi = acos(-1);
    fx1 = f1 * cos(ang1 * pi/180);
    fy1 = f1 * sin(ang1 * pi/180);

    fx2 = f2 * cos(ang2 * pi/180);
    fy2 = f2 * sin(ang2 * pi/180);

    fx3 = f3 * cos(ang3 * pi/180);
    fy3 = f3 * sin(ang3 * pi/180);

    ax = a * cos(angA * pi/180);
    ay = a * sin(angA * pi/180);

    if (f1 == 0)
    {
        fx1 = (masa * ax)-fx2-fx3;
        fy1 = (masa * ay)-fy2-fx3;

        printf("\nEl vector f1 = (%0.2lf)i + (%0.2lf)j", fx1, fy1);

        p1 = pow(fx1, 2);
        p2 = pow(fy1, 2);

        magnitud = sqrt(p1+p2);

        printf("\nLa magnitud del vector f1 es de: %0.2lf", magnitud);
    }
    else if (f2 == 0)
    {
        fx2 = (masa * ax)-fx1-fx3;
        fy2 = (masa * ay)-fy1-fy3;
        printf("\nEl vector f1 = (%0.2lf)i + (%0.2lf)j", fx2, fy2);

        p1 = pow(fx2, 2);
        p2 = pow(fy2, 2);

        magnitud = sqrt(p1+p2);

        printf("\nLa magnitud del vector f1 es de: %0.2lf", magnitud);
    }
    else if (f3 == 0)
    {
        fx3 = (masa * ax)-fx1-fx2;
        fy3 = (masa * ay)-fy1-fy2;
        printf("\nEl vector f1 = (%0.2lf)i + (%0.2lf)j", fx3, fy3);

        p1 = pow(fx3, 2);
        p2 = pow(fy3, 2);

        magnitud = sqrt(p1+p2);

        printf("\nLa magnitud del vector f1 es de: %0.2lf", magnitud);
    }
    
    
    

}