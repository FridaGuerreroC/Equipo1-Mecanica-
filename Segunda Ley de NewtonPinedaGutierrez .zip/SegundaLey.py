import math
import discord
from discord.ext import commands

bot = commands.Bot(command_prefix='!')

@bot.event
async def on_ready():
    print("El bot esta vivo")


bot.run('MTExMDY4MjI0NDY1NTM1ODA4NQ.GoLopA.EWSb5ECcMq5QzMHtxfgWYI5T4OekNVuzK1c3xg')

def main():
    op = 0

    print("1.Formula Simple\n")
    print("2.Con dos fuerzas\n")
    print("3.Con tres fuerzas\n")
    op = int(input("Elija una opcion: "))

    Switch(op)

def Switch(numero):
    fuerza = fuerza1 = fuerza2 = masa = aceleracion = 0.0
    angulo1 = angulo2 = angulo3 = anguloA = 0

    if numero == 1:
        fuerza = float(input("\nIngrese la magnitud de la fuerza (Si no tiene valor, ingrese 0): "))
        masa = float(input("\nIngrese la masa (Si no tiene valor, ingrese 0): "))
        aceleracion = float(input("\nIngrese la magnitud de la aceleración (Si no tiene valor, ingrese 0): "))
        FormulaNormal(fuerza, masa, aceleracion)
    elif numero == 2:
        fuerza = float(input("\nIngrese la magnitud de la fuerza 1 (Si no tiene valor, ingrese 0): "))
        fuerza1 = float(input("\nIngrese la magnitud de la fuerza 2 (Si no tiene valor, ingrese 0): "))
        masa = float(input("\nIngrese la masa (Si no tiene valor, ingrese 0): "))
        aceleracion = float(input("\nIngrese la magnitud de la aceleración (Si no tiene valor, ingrese 0): "))
        angulo1 = int(input("\nIngresa el valor del angulo de la fuerza 1: "))
        angulo2 = int(input("\nIngresa el valor del angulo de la fuerza 2: "))
        anguloA = int(input("\nIngresa el valor del angulo de la aceleracion: "))
        DosFuerzas(fuerza, fuerza1, masa, aceleracion, angulo1, angulo2, anguloA)
    elif numero == 3:
        fuerza = float(input("\nIngrese la magnitud de la fuerza 1 (Si no tiene valor, ingrese 0): "))
        fuerza1 = float(input("\nIngrese la magnitud de la fuerza 2 (Si no tiene valor, ingrese 0): "))
        fuerza2 = float(input("\nIngrese la magnitud de la fuerza 3 (Si no tiene valor, ingrese 0): "))
        masa = float(input("\nIngrese la masa (Si no tiene valor, ingrese 0): "))
        aceleracion = float(input("\nIngrese la magnitud de la aceleración (Si no tiene valor, ingrese 0): "))
        angulo1 = int(input("\nIngresa el valor del angulo de la fuerza 1: "))
        angulo2 = int(input("\nIngresa el valor del angulo de la fuerza 2: "))
        angulo3 = int(input("\nIngresa el valor del angulo de la fuerza 3: "))
        anguloA = int(input("\nIngresa el valor del angulo de la aceleracion: "))
        TresFuerzas(fuerza, fuerza1, fuerza2, masa, aceleracion, angulo1, angulo2, angulo3, anguloA)



def FormulaNormal(fuerza, masa, aceleracion):
    if fuerza == 0:
        fuerza = masa * aceleracion
        print("La fuerza del objeto es de: " + str(fuerza) + " N")
    elif masa == 0:
        masa = fuerza / aceleracion
        print("La masa del objeto es de: " + str(masa) + " Kg")
    elif aceleracion == 0:
        aceleracion = fuerza / masa
        print("La aceleración es de: " + str(aceleracion) + " m/s^2")
    else:
        print("Ya tiene todos los datos completos, no necesita calcular nada :)")


def DosFuerzas(fuerza1, fuerza2, masa, aceleracion, angulo1, angulo2, anguloA):
    fx1 = fx2 = fy1 = fy2 = ax = ay = magnitud = 0.0
    
    #Calculamos las componentes x y y de los vectores
    fx1 = fuerza1 * math.cos(math.radians(angulo1))
    fy1 = fuerza1 * math.sin(math.radians(angulo1))

    fx2 = fuerza2 * math.cos(math.radians(angulo2))
    fy2 = fuerza2 * math.sin(math.radians(angulo2))

    ax = aceleracion * math.cos(math.radians(anguloA))
    ay = aceleracion * math.sin(math.radians(anguloA))

    if fuerza1 == 0:
        fx1 = (masa * ax) - fx2
        fy1 = (masa * ay) - fy2

        magnitud = math.sqrt((fx1 ** 2) + (fy1 ** 2))

        magnitud = "{:.2f}".format(magnitud)

        fx1 = "{:.2f}".format(fx1)
        fy1 = "{:.2f}".format(fy1)

        print("El vector f1 = ("+str(fx1)+")i + ("+str(fy1)+")j")
        print("\nLa magnitud del vector es de: "+str(magnitud)+"N")
    elif fuerza2 == 0:
        fx2 = (masa * ax) - fx1
        fy2 = (masa * ay) - fy1

        magnitud = math.sqrt((fx2 ** 2) + (fy2 ** 2))

        magnitud = "{:.2f}".format(magnitud)
        
        fx2 = "{:.2f}".format(fx2)
        fy2 = "{:.2f}".format(fy2)

        print("El vector f2 = ("+str(fx2)+")i + ("+str(fy2)+")j")
        print("\nLa magnitud del vector es de: "+str(magnitud)+"N")
    elif masa == 0:
        masa = (fx1 + fx2) / ax

        masa = "{:.2f}".format(masa)

        print("La masa es de: "+str(masa)+"Kg")
    elif aceleracion == 0:
        ax = (fx1 + fx2)/masa
        ay = (fy1 + fy2)/masa

        magnitud = math.sqrt((ax ** 2) + (ay ** 2))

        ax = "{:.2f}".format(ax)
        ay = "{:.2f}".format(ay)
        magnitud = "{:.2f}".format(magnitud)

        print("El vector a = ("+str(ax)+")i + ("+str(ay)+")j")
        print("\nLa magnitud del vector aceleracion es de: "+str(magnitud)+"m/s^2")

def TresFuerzas(fuerza1, fuerza2, fuerza3, masa, aceleracion, angulo1, angulo2, angulo3, anguloA):
    fx1 = fx2 = fx3 = fy1 = fy2 = fy3 = ax = ay = magnitud = 0.0
    
    #Calculamos las componentes x y y de los vectores
    fx1 = fuerza1 * math.cos(math.radians(angulo1))
    fy1 = fuerza1 * math.sin(math.radians(angulo1))

    fx2 = fuerza2 * math.cos(math.radians(angulo2))
    fy2 = fuerza2 * math.sin(math.radians(angulo2))

    fx3 = fuerza3 * math.cos(math.radians(angulo3))
    fy3 = fuerza3 * math.sin(math.radians(angulo3))

    ax = aceleracion * math.cos(math.radians(anguloA))
    ay = aceleracion * math.sin(math.radians(anguloA))

    if fuerza1 == 0:
        fx1 = (masa * ax) - fx2 - fx3
        fy1 = (masa * ay) - fy2 - fy3

        magnitud = math.sqrt((fx1 ** 2) + (fy1 ** 2))

        fx1 = "{:.2f}".format(fx1)
        fy1 = "{:.2f}".format(fy1)
        magnitud = "{:.2f}".format(magnitud)

        print("\nEl vector f1 = ("+str(fx1)+"N)i + ("+str(fy1)+"N)j")
        print("\nLa magnitud del vector es de: "+str(magnitud)+"N")
    elif fuerza2 == 0:
        fx2 = (masa * ax) - fx1 - fx3
        fy2 = (masa * ay) - fy1 - fy3

        magnitud = math.sqrt((fx2 ** 2)+(fy2 ** 2))

        fx2 = "{:.2f}".format(fx2)
        fy2 = "{:.2f}".format(fy2)
        magnitud = "{:.2f}".format(magnitud)

        print("\nEl vector f2 = ("+str(fx2)+"N)i + ("+str(fy2+"N)j"))
        print("\nLa magnitud del vector es de: "+str(magnitud)+"N")
    elif fuerza3 == 0:
        fx3 = (masa * ax) - fx1 - fx2
        fy3 = (masa * ay) - fy1 - fy2

        magnitud = math.sqrt((fx3 ** 2)+(fy3 ** 2))

        fx3 = "{:.2f}".format(fx3)
        fy3 = "{:.2f}".format(fy3)
        magnitud = "{:.2f}".format(magnitud)

        print("\nEl vector f3 = ("+str(fx3)+"N)i + ("+str(fy3)+"N)j")
        print("\nLa magnitud del vector es de: "+str(magnitud)+"N")
    elif masa == 0:
        masa = (fx1+fx2+fx3)/ax

        masa = "{:.2f}".format(masa)

        print("\nLa masa es de: "+str(masa)+"Kg")
    elif aceleracion == 0:
        ax = (fx1+fx2+fx3)/masa
        ay = (fy1+fy2+fy3)/masa

        magnitud = math.sqrt((ax ** 2)+(ay ** 2))

        ax = "{:.2f}".format(ax)
        ay = "{:.2f}".format(ay)
        magnitud = "{:.2f}".format(magnitud)

        print("\nEl vector a = ("+str(ax)+"N)i + ("+str(ay)+"N)j")
        print("\nLa magnitud del vector es de: "+str(ay)+"N")



    